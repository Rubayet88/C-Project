﻿namespace inventory
{
    partial class totalAmmountPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.consumptionBox = new MetroFramework.Controls.MetroTextBox();
            this.sellBox = new MetroFramework.Controls.MetroTextBox();
            this.benefitBox = new MetroFramework.Controls.MetroTextBox();
            this.lossBox = new MetroFramework.Controls.MetroTextBox();
            this.showButton = new MetroFramework.Controls.MetroButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel1.Location = new System.Drawing.Point(59, 110);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(207, 25);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel1.TabIndex = 3;
            this.metroLabel1.Text = "তারিখ (Date) বাছাই করুন";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseCustomForeColor = true;
            this.metroLabel1.UseStyleColors = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(293, 115);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(194, 20);
            this.dateTimePicker1.TabIndex = 9;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel2.Location = new System.Drawing.Point(518, 110);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(54, 25);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel2.TabIndex = 10;
            this.metroLabel2.Text = "থেকে";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.UseCustomForeColor = true;
            this.metroLabel2.UseStyleColors = true;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(605, 115);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(194, 20);
            this.dateTimePicker2.TabIndex = 11;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel3.Location = new System.Drawing.Point(12, 295);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(94, 25);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel3.TabIndex = 12;
            this.metroLabel3.Text = "মোট বিক্রি";
            this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel3.UseCustomBackColor = true;
            this.metroLabel3.UseCustomForeColor = true;
            this.metroLabel3.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel4.Location = new System.Drawing.Point(19, 249);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(87, 25);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel4.TabIndex = 13;
            this.metroLabel4.Text = "মোট খরচ";
            this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.UseCustomForeColor = true;
            this.metroLabel4.UseStyleColors = true;
            this.metroLabel4.Click += new System.EventHandler(this.metroLabel4_Click);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel5.Location = new System.Drawing.Point(23, 354);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(44, 25);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel5.TabIndex = 14;
            this.metroLabel5.Text = "লাভ";
            this.metroLabel5.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel5.UseCustomBackColor = true;
            this.metroLabel5.UseCustomForeColor = true;
            this.metroLabel5.UseStyleColors = true;
            this.metroLabel5.Click += new System.EventHandler(this.metroLabel5_Click);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel6.Location = new System.Drawing.Point(19, 411);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(83, 25);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel6.TabIndex = 15;
            this.metroLabel6.Text = "লোকসান";
            this.metroLabel6.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel6.UseCustomBackColor = true;
            this.metroLabel6.UseCustomForeColor = true;
            this.metroLabel6.UseStyleColors = true;
            // 
            // consumptionBox
            // 
            // 
            // 
            // 
            this.consumptionBox.CustomButton.AutoSize = true;
            this.consumptionBox.CustomButton.Image = null;
            this.consumptionBox.CustomButton.Location = new System.Drawing.Point(160, 2);
            this.consumptionBox.CustomButton.Name = "";
            this.consumptionBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.consumptionBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.consumptionBox.CustomButton.TabIndex = 1;
            this.consumptionBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.consumptionBox.CustomButton.UseSelectable = true;
            this.consumptionBox.CustomButton.Visible = false;
            this.consumptionBox.DisplayIcon = true;
            this.consumptionBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.consumptionBox.Lines = new string[0];
            this.consumptionBox.Location = new System.Drawing.Point(129, 249);
            this.consumptionBox.MaxLength = 32767;
            this.consumptionBox.Name = "consumptionBox";
            this.consumptionBox.PasswordChar = '\0';
            this.consumptionBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.consumptionBox.SelectedText = "";
            this.consumptionBox.SelectionLength = 0;
            this.consumptionBox.SelectionStart = 0;
            this.consumptionBox.ShortcutsEnabled = true;
            this.consumptionBox.Size = new System.Drawing.Size(194, 36);
            this.consumptionBox.Style = MetroFramework.MetroColorStyle.Green;
            this.consumptionBox.TabIndex = 16;
            this.consumptionBox.UseSelectable = true;
            this.consumptionBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.consumptionBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.consumptionBox.Click += new System.EventHandler(this.consumptionBox_Click);
            // 
            // sellBox
            // 
            // 
            // 
            // 
            this.sellBox.CustomButton.AutoSize = true;
            this.sellBox.CustomButton.Image = null;
            this.sellBox.CustomButton.Location = new System.Drawing.Point(160, 2);
            this.sellBox.CustomButton.Name = "";
            this.sellBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.sellBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.sellBox.CustomButton.TabIndex = 1;
            this.sellBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.sellBox.CustomButton.UseSelectable = true;
            this.sellBox.CustomButton.Visible = false;
            this.sellBox.DisplayIcon = true;
            this.sellBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.sellBox.Lines = new string[0];
            this.sellBox.Location = new System.Drawing.Point(129, 295);
            this.sellBox.MaxLength = 32767;
            this.sellBox.Name = "sellBox";
            this.sellBox.PasswordChar = '\0';
            this.sellBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.sellBox.SelectedText = "";
            this.sellBox.SelectionLength = 0;
            this.sellBox.SelectionStart = 0;
            this.sellBox.ShortcutsEnabled = true;
            this.sellBox.Size = new System.Drawing.Size(194, 36);
            this.sellBox.Style = MetroFramework.MetroColorStyle.Green;
            this.sellBox.TabIndex = 17;
            this.sellBox.UseSelectable = true;
            this.sellBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.sellBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // benefitBox
            // 
            // 
            // 
            // 
            this.benefitBox.CustomButton.AutoSize = true;
            this.benefitBox.CustomButton.Image = null;
            this.benefitBox.CustomButton.Location = new System.Drawing.Point(160, 2);
            this.benefitBox.CustomButton.Name = "";
            this.benefitBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.benefitBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.benefitBox.CustomButton.TabIndex = 1;
            this.benefitBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.benefitBox.CustomButton.UseSelectable = true;
            this.benefitBox.CustomButton.Visible = false;
            this.benefitBox.DisplayIcon = true;
            this.benefitBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.benefitBox.Lines = new string[0];
            this.benefitBox.Location = new System.Drawing.Point(129, 354);
            this.benefitBox.MaxLength = 32767;
            this.benefitBox.Name = "benefitBox";
            this.benefitBox.PasswordChar = '\0';
            this.benefitBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.benefitBox.SelectedText = "";
            this.benefitBox.SelectionLength = 0;
            this.benefitBox.SelectionStart = 0;
            this.benefitBox.ShortcutsEnabled = true;
            this.benefitBox.Size = new System.Drawing.Size(194, 36);
            this.benefitBox.Style = MetroFramework.MetroColorStyle.Green;
            this.benefitBox.TabIndex = 18;
            this.benefitBox.UseSelectable = true;
            this.benefitBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.benefitBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lossBox
            // 
            // 
            // 
            // 
            this.lossBox.CustomButton.AutoSize = true;
            this.lossBox.CustomButton.Image = null;
            this.lossBox.CustomButton.Location = new System.Drawing.Point(160, 2);
            this.lossBox.CustomButton.Name = "";
            this.lossBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.lossBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.lossBox.CustomButton.TabIndex = 1;
            this.lossBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lossBox.CustomButton.UseSelectable = true;
            this.lossBox.CustomButton.Visible = false;
            this.lossBox.DisplayIcon = true;
            this.lossBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.lossBox.Lines = new string[0];
            this.lossBox.Location = new System.Drawing.Point(129, 411);
            this.lossBox.MaxLength = 32767;
            this.lossBox.Name = "lossBox";
            this.lossBox.PasswordChar = '\0';
            this.lossBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.lossBox.SelectedText = "";
            this.lossBox.SelectionLength = 0;
            this.lossBox.SelectionStart = 0;
            this.lossBox.ShortcutsEnabled = true;
            this.lossBox.Size = new System.Drawing.Size(194, 36);
            this.lossBox.Style = MetroFramework.MetroColorStyle.Green;
            this.lossBox.TabIndex = 19;
            this.lossBox.UseSelectable = true;
            this.lossBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.lossBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // showButton
            // 
            this.showButton.BackColor = System.Drawing.Color.SkyBlue;
            this.showButton.DisplayFocus = true;
            this.showButton.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.showButton.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.showButton.Location = new System.Drawing.Point(129, 162);
            this.showButton.Name = "showButton";
            this.showButton.Size = new System.Drawing.Size(193, 37);
            this.showButton.Style = MetroFramework.MetroColorStyle.White;
            this.showButton.TabIndex = 21;
            this.showButton.Text = "হিসাব দেখুন";
            this.showButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.showButton.UseCustomBackColor = true;
            this.showButton.UseCustomForeColor = true;
            this.showButton.UseSelectable = true;
            this.showButton.Click += new System.EventHandler(this.showButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(473, 195);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(419, 150);
            this.dataGridView1.TabIndex = 22;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(473, 382);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(419, 150);
            this.dataGridView2.TabIndex = 23;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(473, 568);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(419, 150);
            this.dataGridView3.TabIndex = 24;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel7.Location = new System.Drawing.Point(635, 167);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(46, 25);
            this.metroLabel7.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel7.TabIndex = 25;
            this.metroLabel7.Text = "খরচ";
            this.metroLabel7.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel7.UseCustomBackColor = true;
            this.metroLabel7.UseCustomForeColor = true;
            this.metroLabel7.UseStyleColors = true;
            this.metroLabel7.Click += new System.EventHandler(this.metroLabel7_Click_1);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel8.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel8.Location = new System.Drawing.Point(635, 354);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(53, 25);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel8.TabIndex = 26;
            this.metroLabel8.Text = "বিক্রি";
            this.metroLabel8.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel8.UseCustomBackColor = true;
            this.metroLabel8.UseCustomForeColor = true;
            this.metroLabel8.UseStyleColors = true;
            this.metroLabel8.Click += new System.EventHandler(this.metroLabel8_Click);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel9.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel9.Location = new System.Drawing.Point(635, 540);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(72, 25);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel9.TabIndex = 27;
            this.metroLabel9.Text = "ওয়ার্ডার";
            this.metroLabel9.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel9.UseCustomBackColor = true;
            this.metroLabel9.UseCustomForeColor = true;
            this.metroLabel9.UseStyleColors = true;
            // 
            // totalAmmountPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 758);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.showButton);
            this.Controls.Add(this.lossBox);
            this.Controls.Add(this.benefitBox);
            this.Controls.Add(this.sellBox);
            this.Controls.Add(this.consumptionBox);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.metroLabel1);
            this.Name = "totalAmmountPanel";
            this.Text = "totalAmmountPanel";
            this.Load += new System.EventHandler(this.totalAmmountPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox consumptionBox;
        private MetroFramework.Controls.MetroTextBox sellBox;
        private MetroFramework.Controls.MetroTextBox benefitBox;
        private MetroFramework.Controls.MetroTextBox lossBox;
        private MetroFramework.Controls.MetroButton showButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel9;
    }
}