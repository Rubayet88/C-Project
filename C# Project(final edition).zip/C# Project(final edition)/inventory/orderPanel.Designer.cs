﻿namespace inventory
{
    partial class orderPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(orderPanel));
            this.panel1 = new System.Windows.Forms.Panel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.loginButton = new MetroFramework.Controls.MetroButton();
            this.contactBox = new MetroFramework.Controls.MetroTextBox();
            this.typeThree = new MetroFramework.Controls.MetroCheckBox();
            this.dueBox = new MetroFramework.Controls.MetroTextBox();
            this.typeTwo = new MetroFramework.Controls.MetroCheckBox();
            this.advanceBox = new MetroFramework.Controls.MetroTextBox();
            this.typeOne = new MetroFramework.Controls.MetroCheckBox();
            this.totalBox = new MetroFramework.Controls.MetroTextBox();
            this.orderNoBox = new MetroFramework.Controls.MetroTextBox();
            this.descriptionBox = new MetroFramework.Controls.MetroTextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.multiorder = new MetroFramework.Controls.MetroLabel();
            this.orderToggle = new MetroFramework.Controls.MetroToggle();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.metroTextBox1);
            this.panel1.Controls.Add(this.metroButton4);
            this.panel1.Controls.Add(this.metroButton3);
            this.panel1.Controls.Add(this.metroButton2);
            this.panel1.Controls.Add(this.metroButton1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.loginButton);
            this.panel1.Controls.Add(this.contactBox);
            this.panel1.Controls.Add(this.typeThree);
            this.panel1.Controls.Add(this.dueBox);
            this.panel1.Controls.Add(this.typeTwo);
            this.panel1.Controls.Add(this.advanceBox);
            this.panel1.Controls.Add(this.typeOne);
            this.panel1.Controls.Add(this.totalBox);
            this.panel1.Controls.Add(this.orderNoBox);
            this.panel1.Controls.Add(this.descriptionBox);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.metroLabel6);
            this.panel1.Controls.Add(this.metroLabel5);
            this.panel1.Controls.Add(this.metroLabel7);
            this.panel1.Controls.Add(this.metroLabel4);
            this.panel1.Controls.Add(this.metroLabel3);
            this.panel1.Controls.Add(this.metroLabel2);
            this.panel1.Controls.Add(this.metroLabel1);
            this.panel1.Location = new System.Drawing.Point(34, 119);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1063, 594);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.AutoSize = true;
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(140, 2);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.DisplayIcon = true;
            this.metroTextBox1.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(687, 357);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.PromptText = "ওয়ার্ডার নং দিন";
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(174, 36);
            this.metroTextBox1.Style = MetroFramework.MetroColorStyle.Green;
            this.metroTextBox1.TabIndex = 27;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMark = "ওয়ার্ডার নং দিন";
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroButton4
            // 
            this.metroButton4.BackColor = System.Drawing.Color.SkyBlue;
            this.metroButton4.DisplayFocus = true;
            this.metroButton4.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton4.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton4.Location = new System.Drawing.Point(850, 0);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(193, 37);
            this.metroButton4.Style = MetroFramework.MetroColorStyle.White;
            this.metroButton4.TabIndex = 26;
            this.metroButton4.Text = "প্রদর্শন করুন";
            this.metroButton4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButton4.UseCustomBackColor = true;
            this.metroButton4.UseCustomForeColor = true;
            this.metroButton4.UseSelectable = true;
            this.metroButton4.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // metroButton3
            // 
            this.metroButton3.BackColor = System.Drawing.Color.SkyBlue;
            this.metroButton3.DisplayFocus = true;
            this.metroButton3.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton3.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton3.Location = new System.Drawing.Point(867, 462);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(193, 37);
            this.metroButton3.Style = MetroFramework.MetroColorStyle.White;
            this.metroButton3.TabIndex = 25;
            this.metroButton3.Text = "মুছে ফেলুন";
            this.metroButton3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButton3.UseCustomBackColor = true;
            this.metroButton3.UseCustomForeColor = true;
            this.metroButton3.UseSelectable = true;
            this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.BackColor = System.Drawing.Color.SkyBlue;
            this.metroButton2.DisplayFocus = true;
            this.metroButton2.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton2.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton2.Location = new System.Drawing.Point(867, 408);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(193, 37);
            this.metroButton2.Style = MetroFramework.MetroColorStyle.White;
            this.metroButton2.TabIndex = 24;
            this.metroButton2.Text = "আধুনিক করুন";
            this.metroButton2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButton2.UseCustomBackColor = true;
            this.metroButton2.UseCustomForeColor = true;
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.SkyBlue;
            this.metroButton1.DisplayFocus = true;
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton1.Location = new System.Drawing.Point(867, 357);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(193, 37);
            this.metroButton1.Style = MetroFramework.MetroColorStyle.White;
            this.metroButton1.TabIndex = 23;
            this.metroButton1.Text = "নির্বাচন করুন";
            this.metroButton1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(645, 43);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(418, 294);
            this.dataGridView1.TabIndex = 22;
            // 
            // loginButton
            // 
            this.loginButton.BackColor = System.Drawing.Color.SkyBlue;
            this.loginButton.DisplayFocus = true;
            this.loginButton.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.loginButton.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.loginButton.Location = new System.Drawing.Point(297, 437);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(193, 37);
            this.loginButton.Style = MetroFramework.MetroColorStyle.White;
            this.loginButton.TabIndex = 14;
            this.loginButton.Text = "নিবন্ধন করুন";
            this.loginButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.loginButton.UseCustomBackColor = true;
            this.loginButton.UseCustomForeColor = true;
            this.loginButton.UseSelectable = true;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // contactBox
            // 
            // 
            // 
            // 
            this.contactBox.CustomButton.AutoSize = true;
            this.contactBox.CustomButton.Image = null;
            this.contactBox.CustomButton.Location = new System.Drawing.Point(237, 2);
            this.contactBox.CustomButton.Name = "";
            this.contactBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.contactBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.contactBox.CustomButton.TabIndex = 1;
            this.contactBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.contactBox.CustomButton.UseSelectable = true;
            this.contactBox.CustomButton.Visible = false;
            this.contactBox.DisplayIcon = true;
            this.contactBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.contactBox.Lines = new string[0];
            this.contactBox.Location = new System.Drawing.Point(356, 258);
            this.contactBox.MaxLength = 32767;
            this.contactBox.Name = "contactBox";
            this.contactBox.PasswordChar = '\0';
            this.contactBox.PromptText = "মোবাইল নং";
            this.contactBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.contactBox.SelectedText = "";
            this.contactBox.SelectionLength = 0;
            this.contactBox.SelectionStart = 0;
            this.contactBox.ShortcutsEnabled = true;
            this.contactBox.Size = new System.Drawing.Size(271, 36);
            this.contactBox.Style = MetroFramework.MetroColorStyle.Green;
            this.contactBox.TabIndex = 13;
            this.contactBox.UseSelectable = true;
            this.contactBox.WaterMark = "মোবাইল নং";
            this.contactBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.contactBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // typeThree
            // 
            this.typeThree.AutoSize = true;
            this.typeThree.FontSize = MetroFramework.MetroCheckBoxSize.Tall;
            this.typeThree.Location = new System.Drawing.Point(369, 312);
            this.typeThree.Name = "typeThree";
            this.typeThree.Size = new System.Drawing.Size(87, 25);
            this.typeThree.TabIndex = 21;
            this.typeThree.Text = "অন্যান্য";
            this.typeThree.UseSelectable = true;
            this.typeThree.CheckedChanged += new System.EventHandler(this.typeThree_CheckedChanged);
            // 
            // dueBox
            // 
            // 
            // 
            // 
            this.dueBox.CustomButton.AutoSize = true;
            this.dueBox.CustomButton.Image = null;
            this.dueBox.CustomButton.Location = new System.Drawing.Point(237, 2);
            this.dueBox.CustomButton.Name = "";
            this.dueBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.dueBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.dueBox.CustomButton.TabIndex = 1;
            this.dueBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.dueBox.CustomButton.UseSelectable = true;
            this.dueBox.CustomButton.Visible = false;
            this.dueBox.DisplayIcon = true;
            this.dueBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.dueBox.Lines = new string[0];
            this.dueBox.Location = new System.Drawing.Point(356, 208);
            this.dueBox.MaxLength = 32767;
            this.dueBox.Name = "dueBox";
            this.dueBox.PasswordChar = '\0';
            this.dueBox.PromptText = "বাকী টাকা";
            this.dueBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dueBox.SelectedText = "";
            this.dueBox.SelectionLength = 0;
            this.dueBox.SelectionStart = 0;
            this.dueBox.ShortcutsEnabled = true;
            this.dueBox.Size = new System.Drawing.Size(271, 36);
            this.dueBox.Style = MetroFramework.MetroColorStyle.Green;
            this.dueBox.TabIndex = 12;
            this.dueBox.UseSelectable = true;
            this.dueBox.WaterMark = "বাকী টাকা";
            this.dueBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.dueBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // typeTwo
            // 
            this.typeTwo.AutoSize = true;
            this.typeTwo.FontSize = MetroFramework.MetroCheckBoxSize.Tall;
            this.typeTwo.Location = new System.Drawing.Point(206, 312);
            this.typeTwo.Name = "typeTwo";
            this.typeTwo.Size = new System.Drawing.Size(100, 25);
            this.typeTwo.TabIndex = 20;
            this.typeTwo.Text = "এম্বোডারি";
            this.typeTwo.UseSelectable = true;
            // 
            // advanceBox
            // 
            // 
            // 
            // 
            this.advanceBox.CustomButton.AutoSize = true;
            this.advanceBox.CustomButton.Image = null;
            this.advanceBox.CustomButton.Location = new System.Drawing.Point(237, 2);
            this.advanceBox.CustomButton.Name = "";
            this.advanceBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.advanceBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.advanceBox.CustomButton.TabIndex = 1;
            this.advanceBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.advanceBox.CustomButton.UseSelectable = true;
            this.advanceBox.CustomButton.Visible = false;
            this.advanceBox.DisplayIcon = true;
            this.advanceBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.advanceBox.Lines = new string[0];
            this.advanceBox.Location = new System.Drawing.Point(356, 106);
            this.advanceBox.MaxLength = 32767;
            this.advanceBox.Name = "advanceBox";
            this.advanceBox.PasswordChar = '\0';
            this.advanceBox.PromptText = "অগ্রিম টাকা";
            this.advanceBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.advanceBox.SelectedText = "";
            this.advanceBox.SelectionLength = 0;
            this.advanceBox.SelectionStart = 0;
            this.advanceBox.ShortcutsEnabled = true;
            this.advanceBox.Size = new System.Drawing.Size(271, 36);
            this.advanceBox.Style = MetroFramework.MetroColorStyle.Green;
            this.advanceBox.TabIndex = 11;
            this.advanceBox.UseSelectable = true;
            this.advanceBox.WaterMark = "অগ্রিম টাকা";
            this.advanceBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.advanceBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.advanceBox.Click += new System.EventHandler(this.advanceBox_Click);
            this.advanceBox.Leave += new System.EventHandler(this.advanceBox_Leave);
            // 
            // typeOne
            // 
            this.typeOne.AutoSize = true;
            this.typeOne.FontSize = MetroFramework.MetroCheckBoxSize.Tall;
            this.typeOne.Location = new System.Drawing.Point(16, 312);
            this.typeOne.Name = "typeOne";
            this.typeOne.Size = new System.Drawing.Size(152, 25);
            this.typeOne.TabIndex = 19;
            this.typeOne.Text = "টেইলারিং অর্ডার";
            this.typeOne.UseSelectable = true;
            // 
            // totalBox
            // 
            // 
            // 
            // 
            this.totalBox.CustomButton.AutoSize = true;
            this.totalBox.CustomButton.Image = null;
            this.totalBox.CustomButton.Location = new System.Drawing.Point(237, 2);
            this.totalBox.CustomButton.Name = "";
            this.totalBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.totalBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.totalBox.CustomButton.TabIndex = 1;
            this.totalBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.totalBox.CustomButton.UseSelectable = true;
            this.totalBox.CustomButton.Visible = false;
            this.totalBox.DisplayIcon = true;
            this.totalBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.totalBox.Lines = new string[0];
            this.totalBox.Location = new System.Drawing.Point(356, 58);
            this.totalBox.MaxLength = 32767;
            this.totalBox.Name = "totalBox";
            this.totalBox.PasswordChar = '\0';
            this.totalBox.PromptText = "টাকার পরিমান";
            this.totalBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.totalBox.SelectedText = "";
            this.totalBox.SelectionLength = 0;
            this.totalBox.SelectionStart = 0;
            this.totalBox.ShortcutsEnabled = true;
            this.totalBox.Size = new System.Drawing.Size(271, 36);
            this.totalBox.Style = MetroFramework.MetroColorStyle.Green;
            this.totalBox.TabIndex = 10;
            this.totalBox.UseSelectable = true;
            this.totalBox.WaterMark = "টাকার পরিমান";
            this.totalBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.totalBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.totalBox.Leave += new System.EventHandler(this.totalBox_Leave);
            // 
            // orderNoBox
            // 
            // 
            // 
            // 
            this.orderNoBox.CustomButton.AutoSize = true;
            this.orderNoBox.CustomButton.Image = null;
            this.orderNoBox.CustomButton.Location = new System.Drawing.Point(237, 2);
            this.orderNoBox.CustomButton.Name = "";
            this.orderNoBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.orderNoBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.orderNoBox.CustomButton.TabIndex = 1;
            this.orderNoBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.orderNoBox.CustomButton.UseSelectable = true;
            this.orderNoBox.CustomButton.Visible = false;
            this.orderNoBox.DisplayIcon = true;
            this.orderNoBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.orderNoBox.Lines = new string[0];
            this.orderNoBox.Location = new System.Drawing.Point(356, 16);
            this.orderNoBox.MaxLength = 32767;
            this.orderNoBox.Name = "orderNoBox";
            this.orderNoBox.PasswordChar = '\0';
            this.orderNoBox.PromptText = "ওয়ার্ডার নং দিন";
            this.orderNoBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.orderNoBox.SelectedText = "";
            this.orderNoBox.SelectionLength = 0;
            this.orderNoBox.SelectionStart = 0;
            this.orderNoBox.ShortcutsEnabled = true;
            this.orderNoBox.Size = new System.Drawing.Size(271, 36);
            this.orderNoBox.Style = MetroFramework.MetroColorStyle.Green;
            this.orderNoBox.TabIndex = 9;
            this.orderNoBox.UseSelectable = true;
            this.orderNoBox.WaterMark = "ওয়ার্ডার নং দিন";
            this.orderNoBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.orderNoBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.orderNoBox.Leave += new System.EventHandler(this.orderNoBox_Leave);
            // 
            // descriptionBox
            // 
            // 
            // 
            // 
            this.descriptionBox.CustomButton.AutoSize = true;
            this.descriptionBox.CustomButton.Image = null;
            this.descriptionBox.CustomButton.Location = new System.Drawing.Point(160, 2);
            this.descriptionBox.CustomButton.Name = "";
            this.descriptionBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.descriptionBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.descriptionBox.CustomButton.TabIndex = 1;
            this.descriptionBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.descriptionBox.CustomButton.UseSelectable = true;
            this.descriptionBox.CustomButton.Visible = false;
            this.descriptionBox.DisplayIcon = true;
            this.descriptionBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.descriptionBox.Lines = new string[0];
            this.descriptionBox.Location = new System.Drawing.Point(296, 366);
            this.descriptionBox.MaxLength = 32767;
            this.descriptionBox.Name = "descriptionBox";
            this.descriptionBox.PasswordChar = '\0';
            this.descriptionBox.PromptText = "ধরন";
            this.descriptionBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.descriptionBox.SelectedText = "";
            this.descriptionBox.SelectionLength = 0;
            this.descriptionBox.SelectionStart = 0;
            this.descriptionBox.ShortcutsEnabled = true;
            this.descriptionBox.Size = new System.Drawing.Size(194, 36);
            this.descriptionBox.Style = MetroFramework.MetroColorStyle.Green;
            this.descriptionBox.TabIndex = 17;
            this.descriptionBox.UseSelectable = true;
            this.descriptionBox.WaterMark = "ধরন";
            this.descriptionBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.descriptionBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.descriptionBox.Click += new System.EventHandler(this.descriptionBox_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(356, 157);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(271, 20);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel6.Location = new System.Drawing.Point(16, 258);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(218, 25);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel6.TabIndex = 6;
            this.metroLabel6.Text = "মোবাইল নম্বর (Contact No)";
            this.metroLabel6.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel6.UseCustomBackColor = true;
            this.metroLabel6.UseCustomForeColor = true;
            this.metroLabel6.UseStyleColors = true;
            this.metroLabel6.Click += new System.EventHandler(this.metroLabel6_Click);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel5.Location = new System.Drawing.Point(16, 208);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(92, 25);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel5.TabIndex = 5;
            this.metroLabel5.Text = "বাকী(Due)";
            this.metroLabel5.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel5.UseCustomBackColor = true;
            this.metroLabel5.UseCustomForeColor = true;
            this.metroLabel5.UseStyleColors = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel7.Location = new System.Drawing.Point(16, 369);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(203, 25);
            this.metroLabel7.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel7.TabIndex = 14;
            this.metroLabel7.Text = "বিবরন/ধরন (Description)";
            this.metroLabel7.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel7.UseCustomBackColor = true;
            this.metroLabel7.UseCustomForeColor = true;
            this.metroLabel7.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel4.Location = new System.Drawing.Point(16, 157);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(106, 25);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel4.TabIndex = 4;
            this.metroLabel4.Text = "তারিখ(Date)";
            this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.UseCustomForeColor = true;
            this.metroLabel4.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel3.Location = new System.Drawing.Point(16, 105);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(139, 25);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel3.TabIndex = 3;
            this.metroLabel3.Text = "অগ্রিম(Advance)";
            this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel3.UseCustomBackColor = true;
            this.metroLabel3.UseCustomForeColor = true;
            this.metroLabel3.UseStyleColors = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel2.Location = new System.Drawing.Point(16, 58);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(252, 25);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel2.TabIndex = 2;
            this.metroLabel2.Text = "টাকার পরিমান(Total Ammount)";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.UseCustomForeColor = true;
            this.metroLabel2.UseStyleColors = true;
            this.metroLabel2.Click += new System.EventHandler(this.metroLabel2_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.metroLabel1.Location = new System.Drawing.Point(16, 16);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(185, 25);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel1.TabIndex = 1;
            this.metroLabel1.Text = "ওয়ার্ডার নং (Order No)";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseCustomForeColor = true;
            this.metroLabel1.UseStyleColors = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(90, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "ওয়ার্ডার";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(34, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(58, 56);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // multiorder
            // 
            this.multiorder.AutoSize = true;
            this.multiorder.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.multiorder.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.multiorder.Location = new System.Drawing.Point(33, 88);
            this.multiorder.Name = "multiorder";
            this.multiorder.Size = new System.Drawing.Size(143, 25);
            this.multiorder.Style = MetroFramework.MetroColorStyle.Lime;
            this.multiorder.TabIndex = 15;
            this.multiorder.Text = "একাধিক ওয়ার্ডার";
            this.multiorder.Theme = MetroFramework.MetroThemeStyle.Light;
            this.multiorder.UseCustomBackColor = true;
            this.multiorder.UseCustomForeColor = true;
            this.multiorder.UseStyleColors = true;
            // 
            // orderToggle
            // 
            this.orderToggle.AutoSize = true;
            this.orderToggle.Location = new System.Drawing.Point(240, 96);
            this.orderToggle.Name = "orderToggle";
            this.orderToggle.Size = new System.Drawing.Size(80, 17);
            this.orderToggle.TabIndex = 17;
            this.orderToggle.Text = "Off";
            this.orderToggle.UseSelectable = true;
            this.orderToggle.CheckedChanged += new System.EventHandler(this.orderToggle_CheckedChanged_1);
            // 
            // orderPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 700);
            this.Controls.Add(this.orderToggle);
            this.Controls.Add(this.multiorder);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Name = "orderPanel";
            this.Load += new System.EventHandler(this.orderPanel_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private MetroFramework.Controls.MetroTextBox contactBox;
        private MetroFramework.Controls.MetroTextBox dueBox;
        private MetroFramework.Controls.MetroTextBox advanceBox;
        private MetroFramework.Controls.MetroTextBox totalBox;
        private MetroFramework.Controls.MetroTextBox orderNoBox;
        private MetroFramework.Controls.MetroButton loginButton;
        private MetroFramework.Controls.MetroCheckBox typeThree;
        private MetroFramework.Controls.MetroCheckBox typeTwo;
        private MetroFramework.Controls.MetroCheckBox typeOne;
        private MetroFramework.Controls.MetroTextBox descriptionBox;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel multiorder;
        private MetroFramework.Controls.MetroToggle orderToggle;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton metroButton4;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
    }
}